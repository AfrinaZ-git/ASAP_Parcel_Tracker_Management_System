/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.dao;

/**
 *
 * @author Nazira Khairunnisa
 */

import com.mvc.bean.*;
import com.mvc.util.*;
import java.sql.*;

public class SignupDAO {
    public String registerUser(SignupBean signupBean) {
        String adminID = signupBean.getAdmin_ID(); // Get adminID value through signupBean object and store it in temporary variable "adminID"
        String password = signupBean.getPassword(); // Get password value through signupBean object and store it in temporary variable "password"
        String manager_Name = signupBean.getManager_Name(); // Get manager_Name value through signupBean object and store it in temporary variable "manager_Name"
        String manager_Email = signupBean.getManager_Email(); // Get manager_Email value through signupBean object and store it in temporary variable "manager_Email"
        String manager_HP = signupBean.getManager_HP(); // Get manager_HP value through signupBean object and store it in temporary variable "manager_HP"

        String query = "INSERT INTO ADMIN (ADMIN_ID, PASSWORD, MANAGER_NAME, MANAGER_EMAIL, MANAGER_HP) VALUES (?,?,?,?,?)";

        try {
            Connection con = DBConnection.createConnection();

            if (con != null) {
                // Set up the PreparedStatement
                PreparedStatement statement = con.prepareStatement(query);
                statement.setString(1, adminID);
                statement.setString(2, password);
                statement.setString(3, manager_Name);
                statement.setString(4, manager_Email);
                statement.setString(5, manager_HP);

                // Execute the insert query
                int rowsAffected = statement.executeUpdate();

                con.close();
            
                if (rowsAffected > 0) {
                    return "SUCCESS REGISTRATION";
                } else {
                    return "Failed to register user";
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return "Error occurred during registration";
    }
}
