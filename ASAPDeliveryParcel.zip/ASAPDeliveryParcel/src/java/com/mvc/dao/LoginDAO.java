/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.dao;

/**
 *
 * @author Nazira Khairunnisa
 */

import com.mvc.bean.*;
import com.mvc.util.*;
import java.sql.*;

public class LoginDAO {
    public String authorizeLogin(LoginBean loginBean) { // Create authorizeLogin() function
        String adminID = loginBean.getAdminID(); // Get adminID value through loginBean object and store it in temporary variable "adminID"
        String password = loginBean.getPassword(); // Get password value through loginBean object and store it in temporary variable "password"

        Connection con;
        Statement statement;
        ResultSet resultSet;
        String adminID_DB; // Create 2 variables for use next process
        String passwordDB;

        try {
            con = DBConnection.createConnection(); // Fetch DB connection Object
            statement = con.createStatement(); // Statement is used to write queries to database
            resultSet = statement.executeQuery("SELECT ADMIN_ID, PASSWORD FROM ADMIN"); 

            while (resultSet.next()) {
                adminID_DB = resultSet.getString("ADMIN_ID"); // Fetchable database record adminID and password stored in this two variables adminID_DB & passwordDB above created
                passwordDB = resultSet.getString("PASSWORD");

                if(adminID.equals(adminID_DB) && password.equals(passwordDB)) {
                    return "SUCCESS LOGIN";
                }
            }
        } catch (   SQLException ex) {
            ex.printStackTrace();
        }

        return "Wrong Username or Password"; // If invalid condition return string "Wrong username or password"
    }
}
