package com.mvc.util;

import java.sql.*;

public class DBConnection {
    private static final String DB_URL = "jdbc:derby://localhost:1527/parcelDB";
    private static final String USERNAME = "app";
    private static final String PASSWORD = "app";
    private static final String DRIVER = "org.apache.derby.jdbc.ClientDriver";

    public static Connection createConnection() throws SQLException {
        try {
            Class.forName(DRIVER);
            return DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
}