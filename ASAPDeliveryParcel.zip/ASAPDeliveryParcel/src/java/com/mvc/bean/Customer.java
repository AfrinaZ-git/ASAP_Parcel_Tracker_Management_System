/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.bean;

/**
 *
 * @author Nazira Khairunnisa
 */

public class Customer implements java.io.Serializable{
    private String customerId;
    private String customerName;
    private String customerHp;
    private String customerEmail;
    private String customerAddress;
    private String customerGender;

    public Customer() {}

    public Customer(String customerId, String customerName, String customerHp, String customerEmail, String customerAddress, String customerGender) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerHp = customerHp;
        this.customerEmail = customerEmail;
        this.customerAddress = customerAddress;
        this.customerGender = customerGender;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerHp() {
        return customerHp;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public String getCustomerGender() {
        return customerGender;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setCustomerHp(String customerHp) {
        this.customerHp = customerHp;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public void setCustomerGender(String customerGender) {
        this.customerGender = customerGender;
    }
}