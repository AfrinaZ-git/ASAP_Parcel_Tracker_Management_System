/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.bean;

/**
 *
 * @author Nazira Khairunnisa
 */

public class Parcel implements java.io.Serializable{
    private String admin_ID;
    private String customerID;
    private String courier_ID;
    private String tracking_Number;
    private String weight;
    private String destination;
    private String status;

    public Parcel() {}

    public Parcel(String admin_ID, String customerID, String courier_ID, String tracking_Number, String weight, String destination, String status) {
        this.admin_ID = admin_ID;
        this.customerID = customerID;
        this.courier_ID = courier_ID;
        this.tracking_Number = tracking_Number;
        this.weight = weight;
        this.destination = destination;
        this.status = status;
    }

    public String getAdmin_ID() {
        return admin_ID;
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getCourier_ID() {
        return courier_ID;
    }

    public String getTracking_Number() {
        return tracking_Number;
    }

    public String getWeight() {
        return weight;
    }

    public String getDestination() {
        return destination;
    }

    public String getStatus() {
        return status;
    }

    public void setAdmin_ID(String admin_ID) {
        this.admin_ID = admin_ID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public void setCourier_ID(String courier_ID) {
        this.courier_ID = courier_ID;
    }

    public void setTracking_Number(String tracking_Number) {
        this.tracking_Number = tracking_Number;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
