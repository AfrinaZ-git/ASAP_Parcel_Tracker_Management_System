/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.bean;

/**
 *
 * @author Nazira Khairunnisa
 */

public class Courier implements java.io.Serializable{
    private String courier_ID;
    private String courier_Name;
    private String courier_HP;
    private String courier_Email;
    private String courier_Address;

    public Courier() {}

    public Courier(String courier_ID, String courier_Name, String courier_HP, String courier_Email, String courier_Address) {
        this.courier_ID = courier_ID;
        this.courier_Name = courier_Name;
        this.courier_HP = courier_HP;
        this.courier_Email = courier_Email;
        this.courier_Address = courier_Address;
    }

    public String getCourier_ID() {
        return courier_ID;
    }

    public String getCourier_Name() {
        return courier_Name;
    }

    public String getCourier_HP() {
        return courier_HP;
    }

    public String getCourier_Email() {
        return courier_Email;
    }

    public String getCourier_Address() {
        return courier_Address;
    }

    public void setCourierID(String courier_ID) {
        this.courier_ID = courier_ID;
    }

    public void setCourierName(String courier_Name) {
        this.courier_Name = courier_Name;
    }

    public void setCourierHP(String courier_HP) {
        this.courier_HP = courier_HP;
    }

    public void setCourierEmail(String courier_Email) {
        this.courier_Email = courier_Email;
    }

    public void setCourierAddress(String courier_Address) {
        this.courier_Address = courier_Address;
    }
}
