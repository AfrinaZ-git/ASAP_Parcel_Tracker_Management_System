/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.bean;

/**
 *
 * @author Nazira Khairunnisa
 */

public class Admin implements java.io.Serializable{
    private String admin_ID;
    private String password;
    private String manager_Name;
    private String manager_Email;
    private String manager_HP;

    public Admin() {}

    public Admin(String admin_ID, String password, String manager_Name, String manager_Email, String manager_HP) {
        this.admin_ID = admin_ID;
        this.password = password;
        this.manager_Name = manager_Name;
        this.manager_Email = manager_Email;
        this.manager_HP = manager_HP;
    }

    public String getAdmin_ID() {
        return admin_ID;
    }

    public String getPassword() {
        return password;
    }

    public String getManager_Name() {
        return manager_Name;
    }

    public String getManager_Email() {
        return manager_Email;
    }

    public String getManager_HP() {
        return manager_HP;
    }

    public void setAdminID(String admin_ID) {
        this.admin_ID = admin_ID;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setManager_Name(String manager_Name) {
        this.manager_Name = manager_Name;
    }

    public void setManager_Email(String manager_Email) {
        this.manager_Email = manager_Email;
    }

    public void setManager_HP(String manager_HP) {
        this.manager_HP = manager_HP;
    }
}