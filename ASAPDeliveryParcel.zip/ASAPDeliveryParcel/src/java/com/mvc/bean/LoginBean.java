/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.bean;

/**
 *
 * @author Nazira Khairunnisa
 */

public class LoginBean implements java.io.Serializable{
    private String admin_ID;
    private String password;

    public LoginBean() {
        // throw new UnsupportedOperationException("Not supported yet");
    }

    public LoginBean(String admin_ID, String password) {
        this.admin_ID = admin_ID;
        this.password = password;
    }

    public String getAdminID() {
        return admin_ID;
    }

    public String getPassword() {
        return password;
    }

    public void setAdminID(String admin_ID) {
        this.admin_ID = admin_ID;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
