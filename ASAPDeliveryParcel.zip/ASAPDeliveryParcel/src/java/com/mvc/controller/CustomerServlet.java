package com.mvc.controller;

import com.mvc.bean.Customer;
import com.mvc.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;

public class CustomerServlet extends HttpServlet {
    private Connection conn;
    private static final String SELECT_ALL_CUSTOMERS_PAGINATION = "SELECT * FROM CUSTOMER ORDER BY CUSTOMERID OFFSET ? ROW FETCH NEXT ? ROWS ONLY";
    private int noOfRecords;

    @Override
    public void init() {
        try {
            this.conn = DBConnection.createConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Handle GET requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        int page = 1;
        if(request.getParameter("page") != null)
            page = Integer.parseInt(request.getParameter("page"));
        int recordsPerPage = 5;
        
        switch (action) {
            case "list":
                // Fetch all customers and forward to the list view
                List<Customer> customers = getAllCustomers((page-1)*recordsPerPage, recordsPerPage);
                int noOfRecords = getNoOfRecords();
                int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
                request.setAttribute("customers", customers);
                request.setAttribute("noOfPages", noOfPages);
                request.setAttribute("currentPage", page);
                request.getRequestDispatcher("/CustomerForm.jsp").forward(request, response);
                break;
            case "add":
                // Forward to the add customer view
                request.getRequestDispatcher("/addCustForm.jsp").forward(request, response);
                break;
            case "edit":
                // Fetch the customer to be edited and forward to the edit view
                String id = request.getParameter("id");
                Customer customer = getCustomerById(id);
                request.setAttribute("customer", customer);
                request.getRequestDispatcher("/editCustForm.jsp").forward(request, response);
                break;
            case "delete":
                // Delete the customer and redirect to the list view
                id = request.getParameter("id");
                deleteCustomer(id);
                response.sendRedirect("CustomerServlet?action=list");
                break;        
            default:
                // By default, list all customers
                customers = getAllCustomers((page-1)*recordsPerPage, recordsPerPage);
                noOfRecords = getNoOfRecords();
                noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
                request.setAttribute("customers", customers);
                request.setAttribute("noOfPages", noOfPages);
                request.setAttribute("currentPage", page);
                request.getRequestDispatcher("/CustomerForm.jsp").forward(request, response);
                break;
        }
    }

    // Handle POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
        
        
        String action = request.getParameter("action");
        
        if (action == null) {
            action = "list";
        }

        switch (action) {
        case "create":
            // Create a new customer and redirect to the list view
            Customer newCustomer = new Customer();
            
            newCustomer.setCustomerId(request.getParameter("CUSTOMERID"));
            newCustomer.setCustomerName(request.getParameter("CUSTOMERNAME"));
            newCustomer.setCustomerHp(request.getParameter("CUSTOMERHP"));
            newCustomer.setCustomerEmail(request.getParameter("CUSTOMEREMAIL"));
            newCustomer.setCustomerAddress(request.getParameter("CUSTOMERADDRESS"));
            newCustomer.setCustomerGender(request.getParameter("CUSTOMERGENDER"));
            createCustomer(newCustomer);
            response.sendRedirect("CustomerServlet?action=list");
            break;
        case "update":
            // Update an existing customer and redirect to the list view
            Customer updatedCustomer = new Customer();
            updatedCustomer.setCustomerId(request.getParameter("CUSTOMERID"));
            updatedCustomer.setCustomerName(request.getParameter("CUSTOMERNAME"));
            updatedCustomer.setCustomerHp(request.getParameter("CUSTOMERHP"));
            updatedCustomer.setCustomerEmail(request.getParameter("CUSTOMEREMAIL"));
            updatedCustomer.setCustomerAddress(request.getParameter("CUSTOMERADDRESS"));
            updatedCustomer.setCustomerGender(request.getParameter("CUSTOMERGENDER"));
            updateCustomer(updatedCustomer);
            response.sendRedirect("CustomerServlet?action=list");
            break;
        default:
            // By default, redirect to the list view
            response.sendRedirect("CustomerServlet?action=list");
            break;
        }
        
        System.out.println(request.getParameter("CUSTOMERNAME")); // Debug Purposes
    }

    // Fetch all customers from the database
    public List<Customer> getAllCustomers(int offset, int noOfRecords) {
        List<Customer> customers = new ArrayList<>();
        try (PreparedStatement preparedStatement = conn.prepareStatement(SELECT_ALL_CUSTOMERS_PAGINATION)) {
            preparedStatement.setInt(1, offset);
            preparedStatement.setInt(2, noOfRecords);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Customer customer = new Customer();
                // Set customer properties from ResultSet
                customer.setCustomerId(rs.getString("CUSTOMERID"));
                customer.setCustomerName(rs.getString("CUSTOMERNAME"));
                customer.setCustomerHp(rs.getString("CUSTOMERHP"));
                customer.setCustomerEmail(rs.getString("CUSTOMEREMAIL"));
                customer.setCustomerAddress(rs.getString("CUSTOMERADDRESS"));
                customer.setCustomerGender(rs.getString("CUSTOMERGENDER"));
                customers.add(customer);
            }
            
            rs.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return customers;
    }      

    public int getNoOfRecords() {
        return noOfRecords;
    }

    // Fetch a customer by id from the database
    public Customer getCustomerById(String id) {
        Customer customer = null;
        String sql = "SELECT * FROM CUSTOMER WHERE CUSTOMERID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                customer = new Customer();
                // Set customer properties from ResultSet
                if (rs.next()) {
                    customer = new Customer();
                    customer.setCustomerId(rs.getString("CUSTOMERID"));
                    customer.setCustomerName(rs.getString("CUSTOMERNAME"));
                    customer.setCustomerHp(rs.getString("CUSTOMERHP"));
                    customer.setCustomerEmail(rs.getString("CUSTOMEREMAIL"));
                    customer.setCustomerAddress(rs.getString("CUSTOMERADDRESS"));
                    customer.setCustomerGender(rs.getString("CUSTOMERGENDER"));
                }
            }
            
            rs.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return customer;
    }

    // Create a new customer in the database
    public void createCustomer(Customer customer) {
        String sql = "INSERT INTO CUSTOMER (CUSTOMERID, CUSTOMERNAME, CUSTOMERHP, CUSTOMEREMAIL, CUSTOMERADDRESS, CUSTOMERGENDER) VALUES (?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, customer.getCustomerId());
            ps.setString(2, customer.getCustomerName());
            ps.setString(3, customer.getCustomerHp());
            ps.setString(4, customer.getCustomerEmail());
            ps.setString(5, customer.getCustomerAddress());
            ps.setString(6, customer.getCustomerGender());
            ps.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    // Update an existing customer in the database
    public void updateCustomer(Customer customer) {
        String sql = "UPDATE CUSTOMER SET CUSTOMERNAME = ?, CUSTOMERHP = ?, CUSTOMEREMAIL = ?, CUSTOMERADDRESS = ?, CUSTOMERGENDER = ? WHERE CUSTOMERID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, customer.getCustomerName());
            ps.setString(2, customer.getCustomerHp());
            ps.setString(3, customer.getCustomerEmail());
            ps.setString(4, customer.getCustomerAddress());
            ps.setString(5, customer.getCustomerGender());
            ps.setString(6, customer.getCustomerId());
            ps.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    // Delete a customer from the database
    public void deleteCustomer(String id) {
        String sql = "DELETE FROM CUSTOMER WHERE CUSTOMERID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
