package com.mvc.controller;

import com.mvc.bean.Admin;
import com.mvc.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AdminServlet extends HttpServlet {
    private Connection conn;
    private static final String SELECT_ALL_ADMINS_PAGINATION = "SELECT * FROM ADMIN ORDER BY ADMIN_ID OFFSET ? ROW FETCH NEXT ? ROWS ONLY";
    private int noOfRecords;

    @Override
    public void init() {
        try {
            this.conn = DBConnection.createConnection();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    // Handle GET requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        int page = 1;
        if(request.getParameter("page") != null)
            page = Integer.parseInt(request.getParameter("page"));
        int recordsPerPage = 5;
        switch (action) {
            case "list":
                // Fetch all admins and forward to the list view
                List<Admin> admins = getAllAdmins((page-1)*recordsPerPage, recordsPerPage);
                int noOfRecords = getNoOfRecords();
                int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
                request.setAttribute("admins", admins);
                request.setAttribute("noOfPages", noOfPages);
                request.setAttribute("currentPage", page);
                request.getRequestDispatcher("/AdminForm.jsp").forward(request, response);
                break;
            case "add":
                // Forward to the add admin view
                request.getRequestDispatcher("/addAdminForm.jsp").forward(request, response);
                break;
            case "edit":
                // Fetch the admin to be edited and forward to the edit view
                String id = request.getParameter("id");
                Admin admin = getAdminById(id);
                request.setAttribute("admin", admin);
                request.getRequestDispatcher("/editAdminForm.jsp").forward(request, response);
                break;
            case "delete":
                // Delete the admin and redirect to the list view
                id = request.getParameter("id");
                deleteAdmin(id);
                response.sendRedirect("AdminServlet?action=list");
                break;
            default:
                // By default, list all admins
                admins = getAllAdmins((page-1)*recordsPerPage, recordsPerPage);
                noOfRecords = getNoOfRecords();
                noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
                request.setAttribute("admins", admins);
                request.setAttribute("noOfPages", noOfPages);
                request.setAttribute("currentPage", page);
                request.getRequestDispatcher("/AdminForm.jsp").forward(request, response);
                break;
        }
    }

    // Handle POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        
        String action = request.getParameter("action");

        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "create":
                // Create a new admin and redirect to the list view
                Admin newAdmin = new Admin();
                newAdmin.setAdminID(request.getParameter("ADMIN_ID"));
                newAdmin.setPassword(request.getParameter("PASSWORD"));
                newAdmin.setManager_Name(request.getParameter("MANAGER_NAME"));
                newAdmin.setManager_Email(request.getParameter("MANAGER_EMAIL"));
                newAdmin.setManager_HP(request.getParameter("MANAGER_HP"));
                createAdmin(newAdmin);
                response.sendRedirect("AdminServlet?action=list");
                break;
            case "update":
                // Update an existing admin and redirect to the list view
                Admin updatedAdmin = new Admin();
                updatedAdmin.setAdminID(request.getParameter("ADMIN_ID"));
                updatedAdmin.setPassword(request.getParameter("PASSWORD"));
                updatedAdmin.setManager_Name(request.getParameter("MANAGER_NAME"));
                updatedAdmin.setManager_Email(request.getParameter("MANAGER_EMAIL"));
                updatedAdmin.setManager_HP(request.getParameter("MANAGER_HP"));
                updateAdmin(updatedAdmin);
                response.sendRedirect("AdminServlet?action=list");
                break;
            default:
                // By default, redirect to the list view
                response.sendRedirect("AdminServlet?action=list");
                break;
        }
    }

    // Fetch all admins from the database
    public List<Admin> getAllAdmins(int offset, int noOfRecords) {
        List<Admin> admins = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = conn.prepareStatement(SELECT_ALL_ADMINS_PAGINATION);
            preparedStatement.setInt(1, offset);
            preparedStatement.setInt(2, noOfRecords);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Admin admin = new Admin();
                // Set admin properties from ResultSet
                admin.setAdminID(rs.getString("ADMIN_ID"));
                admin.setPassword(rs.getString("PASSWORD"));
                admin.setManager_Name(rs.getString("MANAGER_NAME"));
                admin.setManager_Email(rs.getString("MANAGER_EMAIL"));
                admin.setManager_HP(rs.getString("MANAGER_HP"));
                admins.add(admin);
            }
            rs.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return admins;
    }

    public int getNoOfRecords() {
        return noOfRecords;
    }

    // Fetch an admin by id from the database
    public Admin getAdminById(String id) {
        Admin admin = null;
        String sql = "SELECT * FROM ADMIN WHERE ADMIN_ID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                admin = new Admin();
                // Set admin properties from ResultSet
                admin.setAdminID(rs.getString("ADMIN_ID"));
                admin.setPassword(rs.getString("PASSWORD"));
                admin.setManager_Name(rs.getString("MANAGER_NAME"));
                admin.setManager_Email(rs.getString("MANAGER_EMAIL"));
                admin.setManager_HP(rs.getString("MANAGER_HP"));
            }
            rs.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return admin;
    }

    // Create a new admin in the database
    public void createAdmin(Admin admin) {
        String sql = "INSERT INTO ADMIN (ADMIN_ID, PASSWORD, MANAGER_NAME, MANAGER_EMAIL, MANAGER_HP) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, admin.getAdmin_ID());
            ps.setString(2, admin.getPassword());
            ps.setString(3, admin.getManager_Name());
            ps.setString(4, admin.getManager_Email());
            ps.setString(5, admin.getManager_HP());
            ps.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    // Update an existing admin in the database
    public void updateAdmin(Admin admin) {
        String sql = "UPDATE ADMIN SET PASSWORD = ?, MANAGER_NAME = ?, MANAGER_EMAIL = ?, MANAGER_HP = ? WHERE ADMIN_ID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, admin.getPassword());
            ps.setString(2, admin.getManager_Name());
            ps.setString(3, admin.getManager_Email());
            ps.setString(4, admin.getManager_HP());
            ps.setString(5, admin.getAdmin_ID());
            ps.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    // Delete an admin from the database
    public void deleteAdmin(String id) {
        String sql = "DELETE FROM ADMIN WHERE ADMIN_ID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}