package com.mvc.controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

@WebServlet(name = "DataServlet", urlPatterns = {"/DataServlet"})
public class DataServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Map<String, Integer> customerGenderData = new HashMap<>();
            Map<String, Integer> parcelStatusData = new HashMap<>();
            Map<String, Integer> parcelPerCourierData = new HashMap<>();
            
            // Database Connection
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/parcelDB;create=true;user=app;password=app");

            // Fetch data for Customer Gender chart
            Statement stmt1 = conn.createStatement();
            ResultSet rs1 = stmt1.executeQuery("SELECT CUSTOMER_GENDER, COUNT(*) AS COUNT FROM CUSTOMER GROUP BY CUSTOMER_GENDER");
            while (rs1.next()) {
                customerGenderData.put(rs1.getString("CUSTOMER_GENDER"), rs1.getInt("COUNT"));
            }

            // Fetch data for Parcel Status chart
            Statement stmt2 = conn.createStatement();
            ResultSet rs2 = stmt2.executeQuery("SELECT STATUS, COUNT(*) AS COUNT FROM PARCEL GROUP BY STATUS");
            while (rs2.next()) {
                parcelStatusData.put(rs2.getString("STATUS"), rs2.getInt("COUNT"));
            }

            // Fetch data for Parcels per Courier chart
            Statement stmt3 = conn.createStatement();
            ResultSet rs3 = stmt3.executeQuery("SELECT COURIER_ID, COUNT(*) AS COUNT FROM PARCEL GROUP BY COURIER_ID");
            while (rs3.next()) {
                parcelPerCourierData.put(rs3.getString("COURIER_ID"), rs3.getInt("COUNT"));
            }

            // Convert to JSON and output
            out.println("{");
            out.println("\"customerGenderData\": " + convertToJson(customerGenderData) + ",");
            out.println("\"parcelStatusData\": " + convertToJson(parcelStatusData) + ",");
            out.println("\"parcelPerCourierData\": " + convertToJson(parcelPerCourierData));
            out.println("}");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String convertToJson(Map<String, Integer> data) {
        StringBuilder json = new StringBuilder("{");
        for (Map.Entry<String, Integer> entry : data.entrySet()) {
            json.append("\"").append(entry.getKey()).append("\": ").append(entry.getValue()).append(",");
        }
        // Remove trailing comma and close brace
        if (json.length() > 1) {
            json.setLength(json.length() - 1);
        }
        json.append("}");
        return json.toString();
    }
}