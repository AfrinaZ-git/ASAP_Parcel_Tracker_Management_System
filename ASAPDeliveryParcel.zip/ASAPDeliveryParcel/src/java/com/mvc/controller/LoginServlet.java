package com.mvc.controller;

import com.mvc.bean.LoginBean;
import com.mvc.dao.LoginDAO;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Retrieve the submitted admin_ID and password
        String adminID = request.getParameter("ADMIN_ID"); // retrieve "ADMIN_ID" from parcelDB 
        String password = request.getParameter("PASSWORD"); // retrieve "PASSWORD" from parcelDB
        
        LoginBean loginBean = new LoginBean(); // This class contain seeting up all received values from LogInPage.jsp page to setter & getter method for application require effectively

        loginBean.setAdminID(adminID);
        loginBean.setPassword(password);

        LoginDAO loginDAO = new LoginDAO(); // This class contain main logic to perform function calling and database operations

        String authorize = loginDAO.authorizeLogin(loginBean); // Send loginBean object values into authorizeLogin() function in LoginDao class

        if(authorize.equals("SUCCESS LOGIN")) { // Check calling authorizeLogin() function receive string "SUCCESS LOGIN" message after continue process
            HttpSession session = request.getSession(); // Create a new session
            request.setAttribute("adminID", adminID); // store adminID in "getAdminID()" get through loginBean object
            request.getRequestDispatcher("dashboard.jsp").forward(request, response); // Request to MainMenu.jsp page
        } else {
            request.setAttribute("WrongLoginMsg", authorize); // Wrong login error message is "WrongLoginMsg"
            request.getRequestDispatcher("index.jsp").forward(request, response); // Show error same index.jsp page
        }
    }
}
