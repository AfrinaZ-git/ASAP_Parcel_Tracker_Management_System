
package com.mvc.controller;

import com.mvc.bean.Parcel;
import com.mvc.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;

public class ParcelServlet extends HttpServlet {
    private Connection conn;
    private static final String SELECT_ALL_PARCELS_PAGINATION = "SELECT * FROM PARCEL ORDER BY TRACKING_NUMBER OFFSET ? ROW FETCH NEXT ? ROWS ONLY";
    private int noOfRecords;

    @Override
    public void init() {
        try {
            this.conn = DBConnection.createConnection();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    // Handle GET requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        int page = 1;
        if(request.getParameter("page") != null)
            page = Integer.parseInt(request.getParameter("page"));
        int recordsPerPage = 5;
        switch (action) {
            case "list":
                // Fetch all parcels and forward to the list view
                List<Parcel> parcels = getAllParcels((page-1)*recordsPerPage, recordsPerPage);
                int noOfRecords = getNoOfRecords();
                int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
                request.setAttribute("parcels", parcels);
                request.setAttribute("noOfPages", noOfPages);
                request.setAttribute("currentPage", page);
                request.getRequestDispatcher("/ParcelForm.jsp").forward(request, response);
                break;
            case "add":
                // Forward to the add parcel view
                request.getRequestDispatcher("/addParcelForm.jsp").forward(request, response);
                break;
            case "edit":
                // Fetch the parcel to be edited and forward to the edit view
                String id = request.getParameter("id");
                Parcel parcel = getParcelById(id);
                request.setAttribute("parcel", parcel);
                request.getRequestDispatcher("/editParcelForm.jsp").forward(request, response);
                break;
            case "delete":
                // Delete the parcel and redirect to the list view
                id = request.getParameter("id");
                deleteParcel(id);
                response.sendRedirect("ParcelServlet?action=list");
                break;        
            default:
                // By default, list all parcels
                parcels = getAllParcels((page-1)*recordsPerPage, recordsPerPage);
                noOfRecords = getNoOfRecords();
                noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
                request.setAttribute("parcels", parcels);
                request.setAttribute("noOfPages", noOfPages);
                request.setAttribute("currentPage", page);
                request.getRequestDispatcher("/ParcelForm.jsp").forward(request, response);
                break;
        }
    }

    // Handle POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
        
        
        String action = request.getParameter("action");
        
        if (action == null) {
            action = "list";
        }

        switch (action) {
        case "create":
            // Create a new parcel and redirect to the list view
            Parcel newParcel = new Parcel();
            newParcel.setAdmin_ID(request.getParameter("ADMIN_ID"));
            newParcel.setCustomerID(request.getParameter("CUSTOMERID"));
            newParcel.setCourier_ID(request.getParameter("COURIER_ID"));
            newParcel.setTracking_Number(request.getParameter("TRACKING_NUMBER"));
            newParcel.setWeight(request.getParameter("WEIGHT"));
            newParcel.setDestination(request.getParameter("DESTINATION"));
            newParcel.setStatus(request.getParameter("STATUS"));
            createParcel(newParcel);
            response.sendRedirect("ParcelServlet?action=list");
            break;
        case "update":
            // Update an existing parcel and redirect to the list view
            Parcel updatedParcel = new Parcel();
            updatedParcel.setAdmin_ID(request.getParameter("ADMIN_ID"));
            updatedParcel.setCustomerID(request.getParameter("CUSTOMERID"));
            updatedParcel.setCourier_ID(request.getParameter("COURIER_ID"));
            updatedParcel.setTracking_Number(request.getParameter("TRACKING_NUMBER"));
            updatedParcel.setWeight(request.getParameter("WEIGHT"));
            updatedParcel.setDestination(request.getParameter("DESTINATION"));
            updatedParcel.setStatus(request.getParameter("STATUS"));
            updateParcel(updatedParcel);
            response.sendRedirect("ParcelServlet?action=list");
            break;
        default:
            // By default, redirect to the list view
            response.sendRedirect("ParcelServlet?action=list");
            break;
        }
        
        System.out.println(request.getParameter("ADMIN_ID: " + "ADMIN_ID")); // Debug Purposes
        System.out.println(request.getParameter("CUSTOMERID: " + "CUSTOMERID")); // Debug Purposes
        System.out.println(request.getParameter("COURIER_ID: " + "COURIER_ID")); // Debug Purposes
        System.out.println(request.getParameter("TRACKING_NUMBER: " + "TRACKING_NUMBER")); // Debug Purposes
        System.out.println(request.getParameter("WEIGHT: " + "WEIGHT")); // Debug Purposes
        System.out.println(request.getParameter("DESTINATION: " + "DESTINATION")); // Debug Purposes
        System.out.println(request.getParameter("STATUS: " + "STATUS")); // Debug Purposes
    }

    // Fetch all parcels from the database
    public List<Parcel> getAllParcels(int offset, int noOfRecords) {
        List<Parcel> parcels = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = conn.prepareStatement(SELECT_ALL_PARCELS_PAGINATION);
            preparedStatement.setInt(1, offset);
            preparedStatement.setInt(2, noOfRecords);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Parcel parcel = new Parcel();
                // Set parcel properties from ResultSet
                parcel.setAdmin_ID(rs.getString("ADMIN_ID"));
                parcel.setCustomerID(rs.getString("CUSTOMERID"));
                parcel.setCourier_ID(rs.getString("COURIER_ID"));
                parcel.setTracking_Number(rs.getString("TRACKING_NUMBER"));
                parcel.setWeight(rs.getString("WEIGHT"));
                parcel.setDestination(rs.getString("DESTINATION"));
                parcel.setStatus(rs.getString("STATUS"));
                parcels.add(parcel);
            }
            
            rs.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return parcels;
    }
    
    public int getNoOfRecords() {
        return noOfRecords;
    }

    // Fetch a parcel by id from the database
    public Parcel getParcelById(String id) {
        Parcel parcel = null;
        String sql = "SELECT * FROM PARCEL WHERE TRACKING_NUMBER = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                parcel = new Parcel();
                // Set parcel properties from ResultSet
                parcel.setAdmin_ID(rs.getString("ADMIN_ID"));
                parcel.setCustomerID(rs.getString("CUSTOMERID"));
                parcel.setCourier_ID(rs.getString("COURIER_ID"));
                parcel.setTracking_Number(rs.getString("TRACKING_NUMBER"));
                parcel.setWeight(rs.getString("WEIGHT"));
                parcel.setDestination(rs.getString("DESTINATION"));
                parcel.setStatus(rs.getString("STATUS"));
            }
            
            rs.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return parcel;
    }

    // Create a new parcel in the database
    public void createParcel(Parcel parcel) {
        String sql = "INSERT INTO PARCEL (ADMIN_ID, CUSTOMERID, COURIER_ID, TRACKING_NUMBER, WEIGHT, DESTINATION, STATUS) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, parcel.getAdmin_ID());
            ps.setString(2, parcel.getCustomerID());
            ps.setString(3, parcel.getCourier_ID());
            ps.setString(4, parcel.getTracking_Number());
            ps.setString(5, parcel.getWeight());
            ps.setString(6, parcel.getDestination());
            ps.setString(7, parcel.getStatus());
            ps.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    // Update an existing parcel in the database
    public void updateParcel(Parcel parcel) {
        String sql = "UPDATE PARCEL SET ADMIN_ID = ?, CUSTOMERID = ?, COURIER_ID = ?, WEIGHT = ?, DESTINATION = ?, STATUS = ? WHERE TRACKING_NUMBER = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, parcel.getAdmin_ID());
            ps.setString(2, parcel.getCustomerID());
            ps.setString(3, parcel.getCourier_ID());
            ps.setString(4, parcel.getWeight());
            ps.setString(5, parcel.getDestination());
            ps.setString(6, parcel.getStatus());
            ps.setString(7, parcel.getTracking_Number());
            ps.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    // Delete a parcel from the database
    public void deleteParcel(String id) {
        String sql = "DELETE FROM PARCEL WHERE TRACKING_NUMBER = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }
    
    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
