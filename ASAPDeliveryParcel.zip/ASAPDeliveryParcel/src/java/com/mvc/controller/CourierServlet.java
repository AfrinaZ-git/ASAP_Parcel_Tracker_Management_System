package com.mvc.controller;

import com.mvc.bean.Courier;
import com.mvc.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CourierServlet extends HttpServlet {
    private Connection conn;
    private static final String SELECT_ALL_COURIERS_PAGINATION = "SELECT * FROM COURIER ORDER BY COURIER_ID OFFSET ? ROW FETCH NEXT ? ROWS ONLY";
    private int noOfRecords;

    @Override
    public void init() {
        try {
            this.conn = DBConnection.createConnection();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    // Handle GET requests
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        int page = 1;
        if(request.getParameter("page") != null)
            page = Integer.parseInt(request.getParameter("page"));
        int recordsPerPage = 5;
        switch (action) {
            case "list":
                // Fetch all couriers and forward to the list view
                List<Courier> couriers = getAllCouriers((page-1)*recordsPerPage, recordsPerPage);
                int noOfRecords = getNoOfRecords();
                int noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
                request.setAttribute("couriers", couriers);
                request.setAttribute("noOfPages", noOfPages);
                request.setAttribute("currentPage", page);
                request.getRequestDispatcher("/CourierForm.jsp").forward(request, response);
                break;
            case "add":
                // Forward to the add courier view
                request.getRequestDispatcher("/addCourierForm.jsp").forward(request, response);
                break;
            case "edit":
                // Fetch the courier to be edited and forward to the edit view
                String id = request.getParameter("id");
                Courier courier = getCourierById(id);
                request.setAttribute("courier", courier);
                request.getRequestDispatcher("/editCourierForm.jsp").forward(request, response);
                break;
            case "delete":
                // Delete the courier and redirect to the list view
                id = request.getParameter("id");
                deleteCourier(id);
                response.sendRedirect("CourierServlet?action=list");
                break;        
            default:
                // By default, list all couriers
                couriers = getAllCouriers((page-1)*recordsPerPage, recordsPerPage);
                noOfRecords = getNoOfRecords();
                noOfPages = (int) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
                request.setAttribute("couriers", couriers);
                request.setAttribute("noOfPages", noOfPages);
                request.setAttribute("currentPage", page);
                request.getRequestDispatcher("/CourierForm.jsp").forward(request, response);
                break;
        }
    }

    // Handle POST requests
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
        
        
        String action = request.getParameter("action");
        
        if (action == null) {
            action = "list";
        }

        switch (action) {
        case "create":
            // Create a new courier and redirect to the list view
            Courier newCourier = new Courier();
            newCourier.setCourierID(request.getParameter("COURIER_ID"));
            newCourier.setCourierName(request.getParameter("COURIER_NAME"));
            newCourier.setCourierHP(request.getParameter("COURIER_HP"));
            newCourier.setCourierEmail(request.getParameter("COURIER_EMAIL"));
            newCourier.setCourierAddress(request.getParameter("COURIER_ADDRESS"));
            createCourier(newCourier);
            response.sendRedirect("CourierServlet?action=list");
            break;
        case "update":
            // Update an existing courier and redirect to the list view
            Courier updatedCourier = new Courier();
            updatedCourier.setCourierID(request.getParameter("COURIER_ID"));
            updatedCourier.setCourierName(request.getParameter("COURIER_NAME"));
            updatedCourier.setCourierHP(request.getParameter("COURIER_HP"));
            updatedCourier.setCourierEmail(request.getParameter("COURIER_EMAIL"));
            updatedCourier.setCourierAddress(request.getParameter("COURIER_ADDRESS"));
            updateCourier(updatedCourier);
            response.sendRedirect("CourierServlet?action=list");
            break;
        default:
            // By default, redirect to the list view
            response.sendRedirect("CourierServlet?action=list");
            break;
        }
        
        System.out.println(request.getParameter("ID: " + "COURIER_ID")); // Debug Purposes
        System.out.println(request.getParameter("NAME: " + "COURIER_NAME")); // Debug Purposes
        System.out.println(request.getParameter("NUMBER: " + "COURIER_HP")); // Debug Purposes
        System.out.println(request.getParameter("EMAIL: " + "COURIER_EMAIL")); // Debug Purposes
        System.out.println(request.getParameter("ADDRESS: " + "COURIER_ADDRESS")); // Debug Purposes
    }

    // Fetch all couriers from the database
    public List<Courier> getAllCouriers(int offset, int noOfRecords) {
        List<Courier> couriers = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = conn.prepareStatement(SELECT_ALL_COURIERS_PAGINATION);
            preparedStatement.setInt(1, offset);
            preparedStatement.setInt(2, noOfRecords);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Courier courier = new Courier();
                // Set courier properties from ResultSet
                courier.setCourierID(rs.getString("COURIER_ID"));
                courier.setCourierName(rs.getString("COURIER_NAME"));
                courier.setCourierHP(rs.getString("COURIER_HP"));
                courier.setCourierEmail(rs.getString("COURIER_EMAIL"));
                courier.setCourierAddress(rs.getString("COURIER_ADDRESS"));
                couriers.add(courier);
            }
            
            rs.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return couriers;
    }
    
    public int getNoOfRecords() {
        return noOfRecords;
    }

    // Fetch a courier by id from the database
    public Courier getCourierById(String id) {
        Courier courier = null;
        String sql = "SELECT * FROM COURIER WHERE COURIER_ID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                courier = new Courier();
                // Set courier properties from ResultSet
                if(rs.next()) {
                    courier = new Courier();
                    courier.setCourierID(rs.getString("COURIER_ID"));
                    courier.setCourierName(rs.getString("COURIER_NAME"));
                    courier.setCourierHP(rs.getString("COURIER_HP"));
                    courier.setCourierEmail(rs.getString("COURIER_EMAIL"));
                    courier.setCourierAddress(rs.getString("COURIER_ADDRESS"));
                }
            }
            
            rs.close();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return courier;
    }

    // Create a new courier in the database
    public void createCourier(Courier courier) {
        String sql = "INSERT INTO COURIER (COURIER_ID, COURIER_NAME, COURIER_HP, COURIER_EMAIL, COURIER_ADDRESS) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, courier.getCourier_ID());
            ps.setString(2, courier.getCourier_Name());
            ps.setString(3, courier.getCourier_HP());
            ps.setString(4, courier.getCourier_Email());
            ps.setString(5, courier.getCourier_Address());
            ps.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    // Update an existing courier in the database
    public void updateCourier(Courier courier) {
        String sql = "UPDATE COURIER SET COURIER_NAME = ?, COURIER_HP = ?, COURIER_EMAIL = ?, COURIER_ADDRESS = ? WHERE COURIER_ID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, courier.getCourier_Name());
            ps.setString(2, courier.getCourier_HP());
            ps.setString(3, courier.getCourier_Email());
            ps.setString(4, courier.getCourier_Address());
            ps.setString(5, courier.getCourier_ID());
            ps.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    // Delete a courier from the database
    public void deleteCourier(String id) {
        String sql = "DELETE FROM COURIER WHERE COURIER_ID = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }
    
    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
