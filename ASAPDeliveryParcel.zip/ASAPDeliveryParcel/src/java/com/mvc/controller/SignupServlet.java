package com.mvc.controller;

import com.mvc.bean.SignupBean;
import com.mvc.dao.SignupDAO;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "SignupServlet", urlPatterns = {"/SignupServlet"})
public class SignupServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {    
        // Retrieve the submitted data from SignUpPage.jsp
        String adminID = request.getParameter("ADMIN_ID");  
        String password = request.getParameter("PASSWORD");
        String manager_Name = request.getParameter("MANAGER_NAME");
        String manager_Email = request.getParameter("MANAGER_EMAIL");
        String manager_HP = request.getParameter("MANAGER_HP");
        
        SignupBean signupBean = new SignupBean(); // This class contain seeting up all received values from SignUpPage.jsp page to setter & getter method for application require effectively

        signupBean.setAdminID(adminID);
        signupBean.setPassword(password);
        signupBean.setManager_Name(manager_Name);
        signupBean.setManager_Email(manager_Email);
        signupBean.setManager_HP(manager_HP);

        SignupDAO signupDAO = new SignupDAO(); // This class contain main logic to perform function calling and database operations

        String registerValidate = signupDAO.registerUser(signupBean); // Send signupBean object values into registerUser() function in LoginDao class

        if(registerValidate.equals("SUCCESS REGISTRATION")) { // Check calling registerUser() function receive string "SUCCESS REGISTRATION" message after continue process
            request.setAttribute("adminID", adminID); // store adminID in "getAdminID()" get through signupBean object
            request.getRequestDispatcher("LogInPage.jsp").forward(request, response); // Request to LogInPage.jsp page
        } else {
            request.setAttribute("WrongLoginMsg", registerValidate); // Wrong login error message is "WrongLoginMsg"
            request.getRequestDispatcher("index.jsp").forward(request, response); // Show error same index.jsp page
        }
    }
}
